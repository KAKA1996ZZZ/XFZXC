# Czkawka Core

Core of Czkawka GUI/CLI and Krokiet projects.
